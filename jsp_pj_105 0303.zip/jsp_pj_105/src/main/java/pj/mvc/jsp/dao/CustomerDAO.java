package pj.mvc.jsp.dao;

import pj.mvc.jsp.dto.CustomerDTO;

public interface CustomerDAO {
	
	// 중복확인 처리
	public int idCheck(String strId);
	
	// 회원가입 처리
	public int insertCustomer(CustomerDTO dto);
	
	// 로그인 처리
	public int idPasswordChk(String strid, String strPassword);
	
	// 회원정보 인증 및 탈퇴처리
	public int deleteCustomer(String strId);
	
	// 회원정보 인증 및 상세페이지
	public CustomerDTO getCustomerDetail(String strId);
	
	// 회원정보 수정 처리
	public int updateCustomer(CustomerDTO dto);
	

}
