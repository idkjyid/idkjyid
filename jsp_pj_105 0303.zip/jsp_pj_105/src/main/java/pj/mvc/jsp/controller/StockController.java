package pj.mvc.jsp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pj.mvc.jsp.service.ProductServiceImpl;
import pj.mvc.jsp.util.ImageUploaderHandler;

/*
 * location => 이미지업로드 경로
 *    기본값은 해당 자바가 실행되는 temp 폴더입니다.
 * 
 * fileSizeThreshold 
 * => 입력하지 않을 경우 기본값은 0입니다.
 * 
 * maxFileSize
 * => 파일 1개당 최대 파일 크기
 * 
 */
@WebServlet("*.st")
@MultipartConfig(location="D:\\Dev105\\workspace\\jsp_pj_105\\src\\main\\webapp\\resources\\upload", 
fileSizeThreshold=1024*1024, maxFileSize=1024*1024*5, maxRequestSize=1024*1024*5*5)
public class StockController extends HttpServlet {
   private static final long serialVersionUID = 1L;
   private static final String IMG_UPLOAD_DIR="D:\\Dev105\\workspace\\jsp_pj_105\\src\\main\\webapp\\resources\\upload";
    private ImageUploaderHandler uploader;   
   
   // 1단계. HTTP 요청 받음
   protected void doGet(HttpServletRequest req, HttpServletResponse res) 
         throws ServletException, IOException {
      
      action(req, res);
   }

   protected void doPost(HttpServletRequest req, HttpServletResponse res) 
         throws ServletException, IOException {
      doGet(req, res);
   }
   
   public void action(HttpServletRequest req, HttpServletResponse res) 
         throws ServletException, IOException {
      
      // 한글 안깨지게 처리
	  res.setCharacterEncoding("utf-8");
      req.setCharacterEncoding("utf-8");
      String viewPage = "";
      ProductServiceImpl service = new ProductServiceImpl();
      
      String uri = req.getRequestURI();  
      String contextPath = req.getContextPath();
      String url = uri.substring(contextPath.length());
      
      // 2단계. 요청분석
      if(url.equals("/*.st") || url.equals("/productList.st")) {
         System.out.println("[url ==> /productList.st]");
         
         String contentType = req.getContentType();
         if(contentType != null && contentType.toLowerCase().startsWith("multipart/")) {
        	 uploader = new ImageUploaderHandler();
        	 uploader.setUploadPath(IMG_UPLOAD_DIR); // img 경로 위에 상수로 IMG_UPLOAD_DIR를 선언했음.
        	 uploader.imageUpload(req, res);
         }
         
         viewPage = "manager/stock/productList.jsp";
         service.productList(req, res);
         
         RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
         dispatcher.forward(req, res);
      
      // ------------------- product -----------------------
      // 상품등록 화면    
      } else if(url.equals("/productAdd.st")) {
         System.out.println("[url ==> /productAdd.st]");
         
         
         viewPage = "manager/stock/productAdd.jsp";
         
         RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
         dispatcher.forward(req, res);
         
      // 상품등록 처리   
      } else if(url.equals("/productAddAction.st")) {
         System.out.println("[url ==> /productAddAction.st]"); 
         
         String contentType = req.getContentType();
         if(contentType != null && contentType.toLowerCase().startsWith("multipart/")) {
            uploader = new ImageUploaderHandler();   
            uploader.setUploadPath(IMG_UPLOAD_DIR);   // img 경로
            uploader.imageUpload(req, res);
         }
         
         service.productAddAction(req, res);
         
         viewPage = "manager/stock/productAddAction.jsp";
         
         RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
         dispatcher.forward(req, res);
    
      //상품 상세   
      } else if(url.equals("/productDetail.st")) {
    	  System.out.println("[url ==> /productDetail.st]");
    	  
    	  service.productDetail(req,res);
    	  viewPage = "manager/stock/productDetail.jsp";
    	  
    	  RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
          dispatcher.forward(req, res);
      
      //상품 수정
      } else if(url.equals("/productUpdateAction.st")) {
    	  System.out.println("[url --> /productUpdateAction.st]");
    	  
    	  String contentType = req.getContentType();
			if(contentType != null && contentType.toLowerCase().startsWith("multipart/")) {
				uploader = new ImageUploaderHandler();
				uploader.setUploadPath(IMG_UPLOAD_DIR); // img 경로를 가지고와서 사용하겠다
				uploader.imageUpload(req, res);
			}
			
    	  service.productUpdateAction(req, res);
    	  viewPage = "manager/stock/productUpdateAction.jsp";
    	  
    	  RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
          dispatcher.forward(req, res);
      
      //상품 삭제
      } else if(url.equals("/productDeleteAction.st")) {
    	  System.out.println("[url --> /productDeleteAction.st]");
    	  
    	  service.productDeleteAction(req, res);
    	  
    	  viewPage = "manager/stock/productDeleteAction.jsp";
    	  
    	  RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
          dispatcher.forward(req, res);
    	  
      }
   }

}