package pj.mvc.jsp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import pj.mvc.jsp.dto.ProductDTO;

public class ProductDAOImpl implements ProductDAO {
	
	static ProductDAOImpl instance = new ProductDAOImpl();
	public static ProductDAOImpl getInstance() {
		if(instance == null) {
			instance = new ProductDAOImpl();
		}
		return instance;
	}
	
	private ProductDAOImpl() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/jsp_pj_105");
			
		} catch(NamingException e) {
			e.printStackTrace();
		}
	}
	
	//커넥션 풀 객체를 보관
	   DataSource dataSource;

	//삼품 목록
	@Override
	public List<ProductDTO> productList(int start, int end) {
		System.out.println("DAO - productList");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<ProductDTO> list = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * "
					+	 "FROM ("
					+	 		"SELECT A.*, rownum as rn "
					+	 		"FROM ("
					+			" SELECT pdNo, pdName, pdImg, category, brand, content, price, quantity, status, indate "
					+			   "FROM mvc_product_tbl "
					+			   "ORDER BY pdNo DESC"
					+		") A"	
					+	") "
					+	"WHERE rn BETWEEN ? AND ?";
			System.out.println("sql: " + sql);
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				//1. list 생성
				list = new ArrayList<ProductDTO>();
				
				do {
					//2. dto 생성
					ProductDTO dto = new ProductDTO();
					
					//3. dto에 rs 게시글 정보를 담는다.
					dto.setPdNo(rs.getInt("pdNo"));
					dto.setPdName(rs.getString("pdName"));
					dto.setPdImg(rs.getString("pdImg"));
					dto.setCategory(rs.getString("category"));
					dto.setBrand(rs.getString("brand"));
					dto.setContent(rs.getString("content"));
					dto.setPrice(rs.getInt("price"));
					dto.setQuantity(rs.getInt("quantity"));
					dto.setStatus(rs.getString("status"));
					dto.setIndate(rs.getDate("indate"));
					
					//4. list에 dto를 추가한다.
					list.add(dto);
				} while(rs.next());
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
	
		return list;
	}   
   
	//상품 추가   
	@Override
	public int productInsert(ProductDTO dto) {
	  System.out.println("DAO - productInsert");
      
      Connection conn = null;
      PreparedStatement pstmt = null;
      int insertCnt = 0;
      
      try {
         conn = dataSource.getConnection();
         String sql =  "INSERT INTO mvc_product_tbl(pdNo, pdName, pdImg, category, brand, content, price, quantity, status, indate) "
                  + "VALUES((SELECT NVL(MAX(pdNo) + 1, 1) FROM mvc_product_tbl), ?, ?, ?, ?, ?, ?, ?, ?, sysdate)";
         
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, dto.getPdName());
         pstmt.setString(2, dto.getPdImg());
         pstmt.setString(3, dto.getCategory());
         pstmt.setString(4, dto.getBrand());
         pstmt.setString(5, dto.getContent());
         pstmt.setInt(6, dto.getPrice());
         pstmt.setInt(7, dto.getQuantity());
         pstmt.setString(8, dto.getStatus());
         
         insertCnt = pstmt.executeUpdate();
         
      } catch(SQLException e) {
         e.printStackTrace();
      } finally {
         // 사용한 자원해제
         try {
            if(pstmt != null) pstmt.close();
            if(conn != null) conn.close();
         } catch(SQLException e) {
            e.printStackTrace();
         }
      }
      return insertCnt;

	}
	
	//상품 개수
	@Override	
	public int productUpdate(ProductDTO dto) {
		 System.out.println("dao - productUpdate");
	      
	      int updateCnt = 0;
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      
	      try {
	          conn = dataSource.getConnection();
	          String sql = "UPDATE mvc_product_tbl "
	                  + "SET pdName=?, brand=?, pdImg=?, category=?, content=?, price=?, quantity=?, status=? "
	                  + "WHERE pdNo=?";
	          
	          pstmt = conn.prepareStatement(sql);
	          pstmt.setString(1, dto.getPdName());
	          pstmt.setString(2, dto.getBrand());
	          pstmt.setString(3, dto.getPdImg());
	          pstmt.setString(4, dto.getCategory());
	          pstmt.setString(5, dto.getContent());
	          pstmt.setInt(6, dto.getPrice());
	          pstmt.setInt(7, dto.getQuantity());
	          pstmt.setString(8, dto.getStatus());
	          pstmt.setInt(9, dto.getPdNo());
	          
	          updateCnt = pstmt.executeUpdate();
	          System.out.println("SQL updateCnt : " + updateCnt);
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            if(pstmt != null) pstmt.close();
	            if(conn != null) conn.close();
	         } catch (SQLException e) {
	            e.printStackTrace();
	         }
	      }
	      return updateCnt;
	   }
	

	//상품 상세 페이지
	@Override
	public ProductDTO getProductDetail(int pdNo) {
		System.out.println("product dao - getProductDetail");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		ProductDTO dto = new ProductDTO();
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM mvc_product_tbl where pdNo=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, pdNo);
			System.out.println("sql문 확인 : " + sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto.setPdNo(rs.getInt("pdNo"));
				dto.setBrand(rs.getString("brand"));
				dto.setPdName(rs.getString("pdName"));
				dto.setPdImg(rs.getString("pdImg"));
				dto.setCategory(rs.getString("category"));
				dto.setContent(rs.getString("content"));
				dto.setPrice(rs.getInt("price"));
				dto.setQuantity(rs.getInt("quantity"));
				dto.setStatus(rs.getString("status"));
				dto.setIndate(rs.getDate("indate"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return dto;
	}

	@Override
	public int productDelete(int pdNo) {
	System.out.println("DAO - productDelete()");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		int deleteCnt = 0;
		
		try {
			conn = dataSource.getConnection();
			
			String sql = "DELETE FROM mvc_product_tbl WHERE pdNo=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, pdNo);
			
			deleteCnt = pstmt.executeUpdate();
			System.out.println("deleteResult : "+ deleteCnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return deleteCnt;
	}


	@Override
	public int productCnt() {
		// TODO Auto-generated method stub
		return 0;
	}

}
