package pj.mvc.jsp.service;

import java.sql.Date;
import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pj.mvc.jsp.dao.CustomerDAO;
import pj.mvc.jsp.dao.CustomerDAOImpl;
import pj.mvc.jsp.dto.CustomerDTO;

public class CustomerServiceImpl implements CustomerService {

	// 중복 확인 처리
	@Override
	public void confirmIdAction(HttpServletRequest req, HttpServletResponse res) {
		//중복 확인 3단계.
		String strId = req.getParameter("id");
		
		//중복 확인 4단계. 싱글톤 방식으로 dao 객체 생성, 다형성 적용
		CustomerDAO dao = CustomerDAOImpl.getInstance();
		
		//중복 확인 5단계. 중복확인 처리
		int selectCnt = dao.idCheck(strId);
		
		//중복 확인 6단계. jsp로 처리 결과 전달(request나 session으로 전달)
		req.setAttribute("id", strId);
		req.setAttribute("selectCnt", selectCnt);
	}

	// 회원가입 처리
	@Override
	public void signInAction(HttpServletRequest req, HttpServletResponse res) {
		System.out.println("서비스 => 회원가입처리");
		
		// 3단계. 화면으로부터 입력받은 값을 받아서 dto에 담는다.
		// dto 생성
		CustomerDTO dto = new CustomerDTO();
		dto.setId(req.getParameter("id"));
		dto.setPassword(req.getParameter("password"));
		dto.setName(req.getParameter("name"));
		
		// date타입
		String strDate = req.getParameter("birthday");
		Date date = Date.valueOf(strDate);
		dto.setBirthday(date);
		
		dto.setAddress(req.getParameter("address"));
		
		// hp 필수가 아니므로 null값이 들어올 수 있으므로 값이 존재할 때만 처리
		String hp = "";
		String strHp1 = req.getParameter("hp1");
		String strHp2 = req.getParameter("hp2");
		String strHp3 = req.getParameter("hp3");
		
		if(!strHp1.equals("") && !strHp2.equals("") && !strHp3.equals("")) {
			hp = strHp1 + "-" + strHp2 + "-" + strHp3;
		}
		dto.setHp(hp);
		
		// email
		String email = "";
		String strEmail1 = req.getParameter("email1");
		String strEmail2 = req.getParameter("email2");
		email = strEmail1 + "@" + strEmail2;
		dto.setEmail(email);
		
		// regDate 입력값이 없으면 default가 sysdate로 설정, 아래 행은 time stamp로 설정
		// dto.setRegDate(new Timestamp(System.currentTimeMillis()));
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 작용
		CustomerDAO dao = CustomerDAOImpl.getInstance();
		
		// 5단계. 회원가입 처리
		int insertCnt = dao.insertCustomer(dto);
		System.out.println("서비스 insertCnt : " + insertCnt);
		
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("insertCnt", insertCnt);
	}

	// 로그인 처리
	@Override
	public void loginAction(HttpServletRequest req, HttpServletResponse res) {

		 // 3단계. 화면에서 입력받은 값 받아오기
	      String strId = req.getParameter("id");
	      String strPw = req.getParameter("password");
	      
	     // 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
	      CustomerDAO dao = CustomerDAOImpl.getInstance();
	      
	     // 5단계. 로그인 처리
	      int selectCnt = dao.idPasswordChk(strId, strPw);
	      
	     // 5-1. 로그인 성공
	      if(selectCnt == 1) {
	     
	    	  // 로그인 성공시 세션 ID를 설정
	         req.getSession().setAttribute("customerID", strId);
	      }
	      
	     // 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
	      req.setAttribute("selectCnt", selectCnt);
	   }

	// 회원정보 인증 및 탈퇴처리
	@Override
	public void deleteCustomerAction(HttpServletRequest req, HttpServletResponse res) {
		 // 3단계. 화면에서 입력받은 값 받아오기
			String strId = (String)req.getSession().getAttribute("customerID");
			String strPw = (String)req.getParameter("password");
			
		 // 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
			CustomerDAO dao = CustomerDAOImpl.getInstance();
			
		 // 5-1단계. 회원탈퇴을 위한 인증처리
			int selectCnt = dao.idPasswordChk(strId, strPw);
			int deleteCnt =0;
			
		 // 5-2단계. 인증 성공시 회원탈퇴진행	
			if(selectCnt==1) {  //아이디 비밀번호 일치 시에 delete 가능
				deleteCnt = dao.deleteCustomer(strId);
				System.out.println("서비스 deleteCnt : " + deleteCnt);
			}
			
		 // 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)	
			req.setAttribute("deleteCnt", deleteCnt);
			req.setAttribute("selectCnt", selectCnt);
	}

	// 회원정보 인증 및 상세페이지
	@Override
	public void modifyAction(HttpServletRequest req, HttpServletResponse res) {
		
		//화면으로부터 값 입력받기
		String strId = (String)req.getSession().getAttribute("customerID");	//세션 id
		String strPassword =(String)req.getParameter("password");
		
		//싱글톤
		CustomerDAO dao = CustomerDAOImpl.getInstance();
		
		//회원수정을 위한 인증처리
		int selectCnt = dao.idPasswordChk(strId, strPassword);
		System.out.println("서비스 selectCnt: " + selectCnt);
		
		CustomerDTO dto = null;
		//인증 성공 시 상세 정보 조회
		if(selectCnt==1) {
			dto = dao.getCustomerDetail(strId);
		}
		
		//jsp로 처리 결과 전달
		req.setAttribute("selectCnt", selectCnt);
		req.setAttribute("dto", dto);
	}

	// 회원정보 수정 처리
	@Override
	public void modifyCustomerAction(HttpServletRequest req, HttpServletResponse res) {
		
		// 3단계. dto 생성 후, 화면에서 입력받은 값 받아오기
			CustomerDTO dto = new CustomerDTO();
		
		 // 3-1단계 화면이나 세션으로부터 입력받은 값을 dto에 담기	
			dto.setId((String)req.getSession().getAttribute("customerID"));	//세션 id
			dto.setPassword(req.getParameter("password"));
			dto.setName(req.getParameter("name"));
			
			// date타입
			String birthday = req.getParameter("birthday");
			Date birth = Date.valueOf(birthday);
			dto.setBirthday(birth);
			
			dto.setAddress(req.getParameter("address"));
			
			// hp 필수가 아니므로 null값이 들어올 수 있으므로 값이 존재할 때만 처리
			String hp = "";
			String strHp1 = req.getParameter("hp1");
			String strHp2 = req.getParameter("hp2");
			String strHp3 = req.getParameter("hp3");
			
			if(!strHp1.equals("") && !strHp2.equals("") && !strHp3.equals("")) {
				hp = strHp1 + "-" + strHp2 + "-" + strHp3;
			}
			dto.setHp(hp);
			
			// email
			String email = "";
			String strEmail1 = req.getParameter("email1");
			String strEmail2 = req.getParameter("email2");
			email = strEmail1 + "@" + strEmail2;
			dto.setEmail(email);
			
			
	     // 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
	      CustomerDAO dao = CustomerDAOImpl.getInstance();
	      
	     // 5단계. 회원 수정 처리
	      int updateCnt = dao.updateCustomer(dto);
	      System.out.println("서비스 updateCnt: " + updateCnt);
	      
	     // 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
	      req.setAttribute("updateCnt", updateCnt);
		
	}

	// 이메일 인증
	@Override
	public void emailChkAction(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub
		
	}

}
