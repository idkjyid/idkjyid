package pj.mvc.jsp.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import page.Paging;
import pj.mvc.jsp.dao.ProductDAO;
import pj.mvc.jsp.dao.ProductDAOImpl;
import pj.mvc.jsp.dto.ProductDTO;

public class ProductServiceImpl implements ProductService {
	// 상품목록
	@Override
  public void productList(HttpServletRequest req, HttpServletResponse res) {
	System.out.println("서비스 - productList");
	// 3단계. 화면으로부터 입력받은 값을 받는다.
	String pageNum = req.getParameter("pageNum");
	
	// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
	ProductDAO dao = ProductDAOImpl.getInstance();
	
	// 5-1단계.
	Paging paging = new Paging(pageNum);
	
	// product 카운트
	int total = dao.productCnt();
	paging.setTotalCount(total);
	System.out.println("total => " + total);
	
	int start = paging.getStartRow(); // 페이지별 시작번호
	int end = paging.getEndRow(); // 페이지별 끝번호
	
	// 5-2단계. 리스트 조회 (dao 생성하여 상품리스트 조회후 결과 받아오기
	List<ProductDTO> list = dao.productList(start, end);
	
	System.out.println("list ==> " + list);
	
	// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
	req.setAttribute("list", list);
	req.setAttribute("paging", paging);
	}
		
    // 상품추가 처리
   @Override
   public void productAddAction(HttpServletRequest req, HttpServletResponse res) {
      System.out.println("서비스 - productAddAction");
      
      // 3단계. 화면으로부터 입력받은 값을 받아서 dto에 담는다.
      ProductDTO dto = new ProductDTO();
      dto.setPdName(req.getParameter("pdName"));
      // 플젝명/upload 해당 경로
      // ImageUploaderHandler 클래스에서 setAttribute()로 넘겼으므로
      String p_img1 = "/jsp_pj_105/resources/upload/" + (String)req.getAttribute("fileName");  // 플젝명/경로
      System.out.println("dto.getPdImg() : ");
      dto.setPdImg(p_img1);
      
      dto.setCategory(req.getParameter("category"));
      dto.setBrand(req.getParameter("brand"));
      dto.setContent(req.getParameter("content"));
      dto.setPrice(Integer.parseInt(req.getParameter("price")));
      dto.setQuantity(Integer.parseInt(req.getParameter("quantity")));
      dto.setStatus(req.getParameter("status"));
      
      // 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
      ProductDAO dao = ProductDAOImpl.getInstance();
      
      // 5단계. 상품정보 insert
      int insertCnt = dao.productInsert(dto);
      
      System.out.println("insertCnt : " + insertCnt);  // 정상 : 1
      
      // 1   비스포크   /jsp_pj_105/resources/upload/비스포크냉장고.jpg   주방가전   삼성   비스포크 디자인, 성능 최신형   890000   5   판매중   22/02/28
      // upload폴더를 새로고침하면 등록한 이미지가 들어온다.
      
      // 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
      req.setAttribute("insertCnt", insertCnt);
   }
	   
	// 상세페이지
   @Override
   public void productDetail(HttpServletRequest req, HttpServletResponse res) {
	   System.out.println("product service - productDetail");
		
		//화면 입력 받은 값을 받아
		String pageNum = req.getParameter("pageNum");
		int pdNo = Integer.parseInt(req.getParameter("pdNo"));
		
		//싱글톤 방식으로 dao객체 생성, 다형성 적용
		ProductDAO dao = ProductDAOImpl.getInstance();
		
		//상품 정보 조회
		ProductDTO dto = new ProductDTO();
		dto = dao.getProductDetail(pdNo);
		
		//jsp로 처리 결과 전달
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("dto", dto);
      
   }
	
	// 상품수정 처리
	@Override
	public void productUpdateAction(HttpServletRequest req, HttpServletResponse res) {
		// 3. 화면으로 부터 입력받은 값을 받아서 dto에 담는다.
		// 화면값 받아오기(hidden값)
		ProductDTO dto = new ProductDTO();
		
		String pageNum = req.getParameter("pageNum");
		int hiddenPdNo = Integer.parseInt(req.getParameter("hiddenPdNo"));
		String hiddenPdImg = req.getParameter("hiddenPdImg");
		String uploadPdImg = (String)req.getAttribute("fileName");
		
		// 화면값 받아오기
		dto.setPdNo(hiddenPdNo);
		dto.setPdName(req.getParameter("pdName"));
		dto.setBrand(req.getParameter("brand"));
		String pdImg = req.getParameter("pdImg");
		
		String strPdImg = "";
		System.out.println("strPdImg : " + strPdImg);
	
		// 이미지를 수정하지 않았을 때
		if(pdImg == "") {
			// 기존 이미지 활용
			System.out.println("pdImg ====> " + strPdImg);
			strPdImg = hiddenPdImg;
		// 이미지를 수정했을 때
		} else {
			// 수정된 이미지 경로 사용
			strPdImg = "/jsp_pj_105/resources/upload/" + uploadPdImg;
			System.out.println("pdImg !!!!!!!!!=====>" + strPdImg);
		}
		
		// 화면값 받아오기
	      dto.setPdNo(hiddenPdNo);
	      dto.setPdName(req.getParameter("pdName")); 
	      dto.setBrand(req.getParameter("brand"));
	      dto.setPdImg(strPdImg);
	      dto.setCategory(req.getParameter("category"));  
	      dto.setContent(req.getParameter("content"));
	      dto.setPrice(Integer.parseInt(req.getParameter("price")));
	      dto.setQuantity(Integer.parseInt(req.getParameter("quantity")));
	      dto.setStatus(req.getParameter("status"));
		
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		ProductDAO dao = ProductDAOImpl.getInstance();
		
		// 5단계. 상품정보 수정
		int updateCnt = dao.productUpdate(dto);
		
	    // 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("updateCnt", updateCnt);
		req.setAttribute("pageNum", pageNum);
		
	}
	
	// 상품삭제 처리
	@Override
	public void productDeleteAction(HttpServletRequest req, HttpServletResponse res) {
		System.out.println("productDelete service");
		
		// 3. 화면으로 부터 입력받은 값을 받아서 dto에 담는다.
		int pdNo = Integer.parseInt(req.getParameter("pdNo"));
		String pageNum = req.getParameter("pageNum");
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
	    ProductDAO dao = ProductDAOImpl.getInstance();
	    
		// 5단계. 상품정보 삭제
	    int deleteCnt = dao.productDelete(pdNo);
	    
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
	    req.setAttribute("deleteCnt", deleteCnt);
	    req.setAttribute("pageNum", pageNum);
	}
	

}