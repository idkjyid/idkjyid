package pj.mvc.jsp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import pj.mvc.jsp.dto.CustomerDTO;

public class CustomerDAOImpl implements CustomerDAO {
	
	// 싱글톤 방식 : 객체를 1번만 생성
	static CustomerDAOImpl instance = new CustomerDAOImpl();
	public static CustomerDAOImpl getInstance() {
		if(instance == null) {
			instance = new CustomerDAOImpl();
		}
		return instance;
	}
	
	// 생성자
	private CustomerDAOImpl() {
		/*
		 * [커넥션풀] : 매번 connection을 만들지 말고 커넥션풀 이용(context.xml 이용)
		 * DBCP(datBase Connection Pool) 설정을 읽어서 커넥션을 발급받겠다.
		 * 1. Context : Servers > context.xml 파일의 Resource 객체에 추가
		 * 2. lookup("java.comp/env/[커넥션풀 name]);
		 * 주의사항 : 톰켓 재설치시 resource 정보가 날라가므로 재추가할 것
		 */
		// 커넥션 풀 객체를 보관
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/jsp_pj_105"); /* datasource로 형변환 */
			
		} catch(NamingException e) {
			e.printStackTrace();
		}
	};

	// 중복확인 처리
	@Override
	public int idCheck(String strId) {
		System.out.println("dao - id 중복 확인 처리");
		int selectCnt = 0;
		Connection conn = null;  // 오라클 연결
		PreparedStatement pstmt = null;  // SQL 문장
		ResultSet rs = null;	//selct문에서만 사용하는 resultset
		
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM mvc_customer_tbl WHERE id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				selectCnt = 1;
			} 
			
		} catch(SQLException e) {
			e.printStackTrace();
			
		} finally {
			//사용한 자원해제
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return selectCnt;
	}

	// 커넥션 풀 객체를 보관
	DataSource dataSource;
			
	// 회원가입 처리
		@Override
		public int insertCustomer(CustomerDTO dto) {
			System.out.println("dao - 회원가입처리");
			
			int insertCnt = 0;
			Connection conn = null;  // 오라클 연결
			PreparedStatement pstmt = null;  // SQL 문장
			
			try {
				conn = dataSource.getConnection();
				String sql = "INSERT INTO mvc_customer_tbl(id, password, name, birthday, address, hp, email, regDate) VALUES(?,?,?,?,?,?,?,sysdate)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, dto.getId());
				pstmt.setString(2, dto.getPassword());
				pstmt.setString(3, dto.getName());
				pstmt.setDate(4, dto.getBirthday());
				pstmt.setString(5, dto.getAddress());
				pstmt.setString(6, dto.getHp());
				pstmt.setString(7, dto.getEmail());
				/* pstmt.setTimestamp(8, dto.getRegDate()); */
				// 이메일 인증키
				
				insertCnt = pstmt.executeUpdate();  // 입력성공:1 입력실패:0
				System.out.println("inserCnt : " + insertCnt);
				
			} catch(SQLException e) {
				e.printStackTrace();
			} finally {
				// 사용한 자원 해제
				try {
					if(pstmt != null) pstmt.close();
					if(conn != null) conn.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
			return insertCnt;
		}

	// 로그인 처리, 회원정보 인증(수정, 탈퇴)
	@Override
	public int idPasswordChk(String strId, String strPassword) {
		System.out.println("dao - 로그인 처리, 회원정보 인증(수정, 탈퇴)");
		int selectCnt =0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM mvc_customer_tbl WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			
			rs = pstmt.executeQuery(); 
			
			//로그인한 id와 일치하고
			if(rs.next()) {
			//패스워드가 일치하면 selectCnt = 1
				if(strPassword.equals(rs.getString("password"))) {
					selectCnt = 1;
				} else {
			//패스워드가 불일치하면 selectCnt = -1
					selectCnt = -1;
				}
			//id와 불일치하면 비가입 selectCnt = 0
			} else {
				selectCnt =0;
			}
			System.out.println("SQL selectCnt: " + selectCnt);
			
		} catch(SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return selectCnt;
	}

	// 회원정보 인증 및 탈퇴처리
	@Override
	public int deleteCustomer(String strId) {
		System.out.println("dao - 회원 탈퇴 처리");
		
		int deleteCnt =0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			
			conn = dataSource.getConnection();
		
			String sql = "DELETE FROM mvc_customer_tbl WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1,strId);
			
			deleteCnt = pstmt.executeUpdate(); //삭제 성공:1, 삭제 실패:0
			
		} catch(SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return deleteCnt;
	}

	// 회원정보 인증 및 상세페이지
	@Override
	public CustomerDTO getCustomerDetail(String strId) {
		System.out.println("dao - 로그인 처리, 회원정보 인증(수정, 탈퇴)");
		int selectCnt =0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		//1.바구니 생성
		CustomerDTO dto = new CustomerDTO();
		
		try {
			
			conn = dataSource.getConnection();
		
			//2.strId(로그인 화면에서 입력받은 세션 id)와 일치하는 데이터가 있는지 조회
			String sql = "SELECT * FROM mvc_customer_tbl WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			
			rs = pstmt.executeQuery(); 
			
			//3. ResultSet에 id와 일치하는 한 사람의 회원 정보가 존재하면
			if(rs.next()) {
				
				//resultSet을 읽어서 DTO에 setter로 담는다.
				dto.setId(rs.getString("id"));
				dto.setPassword(rs.getString("password"));
				dto.setName(rs.getString("name"));
				dto.setBirthday(rs.getDate("birthday"));
				dto.setHp(rs.getString("hp"));
				dto.setEmail(rs.getString("email"));
				dto.setRegDate(rs.getTimestamp("regDate"));
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		//5. CustomerDTO를 리턴
		return dto;
	}
	
	// 회원정보 수정 처리
	@Override
	public int updateCustomer(CustomerDTO dto) {
		System.out.println("dao - 회원 정보 수정 처리");
		int updateCnt =0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			
			conn = dataSource.getConnection();
		
			String sql = "UPDATE mvc_customer_tbl SET password=?, name=?, birthday=?, address=?, hp=?, email=? WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1,dto.getPassword());
			pstmt.setString(2,dto.getName());
			pstmt.setDate(3,dto.getBirthday());
			pstmt.setString(4,dto.getAddress());
			pstmt.setString(5,dto.getHp());
			pstmt.setString(6,dto.getEmail());
			pstmt.setString(7,dto.getId());
			
			updateCnt = pstmt.executeUpdate(); //수정 성공:1, 수정 실패:0
			
			
		} catch(SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return updateCnt;
	}

}
