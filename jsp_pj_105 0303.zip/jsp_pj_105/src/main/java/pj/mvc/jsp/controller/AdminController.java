package pj.mvc.jsp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pj.mvc.jsp.service.BoardServiceImpl;

@WebServlet("*.ad")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	// 1단계. 웹브라우저가 전송한 HTTP 요청 받음
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		action(req, res);
	}
	// 1단계. 웹브라우저가 전송한 HTTP 요청 받음
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
	public void action(HttpServletRequest req,HttpServletResponse res)
			throws ServletException, IOException {
		
		// 한글처리
		req.setCharacterEncoding("UTF-8");
		String viewPage = ""; // 페이지 결과를 받을 변수 선언
		
		// BoardService 객체 생성
		BoardServiceImpl service = new BoardServiceImpl();
		
		String uri = req.getRequestURI(); // request받은 URI를 받을 변수 선언
		String contextPath = req.getContextPath(); // 프로젝트명 가져오는 메서드
		String url = uri.substring(contextPath.length());
		
		// 2단계. 요청분석
		if(url.equals("/*.ad") || url.equals("/boardList.ad")) {   
			System.out.println("[url ==> /boardList.ad");
			service.boardList(req, res);
			viewPage = "/manager/csCenter/boardList.jsp";
			
			RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
			dispatcher.forward(req, res);
		
		//게시판 글쓰기 버튼
		}else if(url.equals("/board_insert.ad")) {	
			System.out.println("[url ==> /board_insert.ad");
			viewPage = "manager/csCenter/board_insert.jsp";
			
			RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
			dispatcher.forward(req, res);
		
		//게시판 게시물 등록 버튼
		}else if(url.equals("/board_insertAction.ad")) {
			System.out.println("[url ==> /board_insertAction.ad");
			service.boardInsert(req, res);
			
		/*	board_insertAction.jsp 페이지 만들지 않고 바로 board_list.jsp로 이동
			viewPage가 없는 경우 /board_insertAction.ad 주소상태로 빈 화면이 나온다.
			즉 화면이동이 없다. 틀리면 404오류 발생. url과 값이 같이 간다.			*/
			
			viewPage = req.getContextPath() + "/boardList.ad";
			res.sendRedirect(viewPage);
		
		//게시글 상세 페이지 (게시글 제목 눌렀을 때 해당 게시글의 번호를 key값으로 글 내용 전달)
		}else if(url.equals("/board_detailAction.ad")) {
			/* Action이 붙어있으면 Service 실행됨 */
			System.out.println("[url ==> /board_detailAction.ad]");
			
			service.boardDetail(req, res);
			
			viewPage = "manager/csCenter/board_detailAction.jsp"; 
			RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage); 
			dispatcher.forward(req, res);
		
		//게시글 수정 삭제시 비밀번호 체크
		}else if(url.equals("/password_chk.ad")) {
			System.out.println("[url ==> /password_chk.ad]");
			
			//서비스에서 페이지까지 핸들링
			service.password_chk(req, res);
		
		//게시글 수정 처리
		}else if(url.equals("/board_updateAction.ad")) {
			System.out.println("[url ==> /board_updateAction.ad]");
			service.boardUpdate(req, res);
			// 현재 게시글 번호 가져오기
			int num = Integer.parseInt(req.getParameter("num"));
			
			viewPage = req.getContextPath()+"/board_detailAction.ad?num="+num;
			res.sendRedirect(viewPage);
		
		//게시글 삭제 처리
		}else if(url.equals("/board_deleteAction.ad")) {
			System.out.println("[url ==> /board_deleteAction.ad]");
			
			service.boardDelete(req, res);
			viewPage = req.getContextPath()+"/boardList.ad";
			res.sendRedirect(viewPage);
		
		//댓글
		}else if(url.equals("/commentAdd.ad")) {
			System.out.println("[url ==> /commentAdd.ad]");
			
			service.commentAdd(req, res); /*$.ajax()의 콜백함수(success)로 넘어감*/
			
		//댓글 목록	
		}else if(url.equals("/commentList.ad")) {	
			System.out.println("[url ==> /commentList.ad]");
			
			service.commentList(req, res); /*$.ajax()의 콜백함수(success)로 넘어감*/
			
			viewPage = "manager/csCenter/comment_list.jsp";
			RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage); 
			dispatcher.forward(req, res);
			
		//로그아웃 처리
		}else if(url.equals("logout.ad")) {
			System.out.println("[url ==> logout.ad]");
			viewPage = "/common/main.jsp";
			RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage); 
			dispatcher.forward(req, res);
		}
		/*
			dispatcher.forward(); 는 url은 바뀌지 않고 결과만 바꾼 상태를 보여주고
			res.sendRedirect(); 시스템에 변화가 생기는 요청(회원가입, 글쓰기 등)의 경우에는 redirection을 사용하는 것이 바람직
		*/
	}

}
