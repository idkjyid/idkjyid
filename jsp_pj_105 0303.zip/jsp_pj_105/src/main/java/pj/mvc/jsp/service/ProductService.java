package pj.mvc.jsp.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface ProductService {

	//삼품 조회
	public void productList(HttpServletRequest req, HttpServletResponse res);
	
	//상품 등록
	public void productAddAction(HttpServletRequest req, HttpServletResponse res);
	
	//상품 수정
	public void productUpdateAction(HttpServletRequest req, HttpServletResponse res);
	
	//상품 삭제
	public void productDeleteAction(HttpServletRequest req, HttpServletResponse res);
	
	//상품 상세
	public void productDetail(HttpServletRequest req, HttpServletResponse res);
	
}
