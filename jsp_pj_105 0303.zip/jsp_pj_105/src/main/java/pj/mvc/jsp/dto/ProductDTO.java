package pj.mvc.jsp.dto;

import java.sql.Date;

public class ProductDTO {

	private int pdNo;
	private String pdName;
	private String pdImg;
	private String category;
	private String brand;
	private String content;
	private int price;
	private int quantity;
	private String status;
	private Date indate;
	
	public ProductDTO() {}
	
	public int getPdNo() {
		return pdNo;
	}
	
	public void setPdNo(int pdNo) {
		this.pdNo = pdNo;
	}
	
	public String getPdName() {
		return pdName;
	}
	
	public void setPdName(String pdName) {
		this.pdName = pdName;
	}
	
	public String getPdImg() {
		return pdImg;
	}
	
	public void setPdImg(String pdImg) {
		this.pdImg = pdImg;
	}
	
	public String getCategory() {
		return category;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getBrand() {
		return brand;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
	
	public int getPrice() {
		return price;
	}
	
	public void setPrice(int price) {
		this.price = price;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Date getIndate() {
		return indate;
	}
	
	public void setIndate(Date indate) {
		this.indate = indate;
	}
	
	@Override
	public String toString() {
		return "ProductDTO [pdNo=" + pdNo + ", pdName=" + pdName + ", pdImg=" + pdImg + ", category=" + category
				+ ", brand=" + brand + ", content=" + content + ", price=" + price + ", quantity=" + quantity
				+ ", status=" + status + ", indate=" + indate + "]";
	}
	
	
	
}
/*
CREATE TABLE mvc_product_tbl (
	pdNo        NUMBER    		PRIMARY KEY,
	pdName      VARCHAR2(50)    NOT NULL UNIQUE,
	pdImg       VARCHAR2(100)   NOT NULL,
	category    VARCHAR2(50)    NOT NULL,
	brand       VARCHAR2(50)    NOT NULL,
	content     CLOB,
	price       NUMBER          NOT NULL,
	quantity    NUMBER          NOT NULL,
	status      VARCHAR2(20)    NOT NULL,
	indate      DATE            DEFAULT sysdate    
);
 */

