package pj.mvc.jsp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import pj.mvc.jsp.dto.BoardCommentDTO;
import pj.mvc.jsp.dto.BoardDTO;

public class BoardDAOImpl implements BoardDAO{
	
	// 1. 싱글톤
	static BoardDAOImpl instance = new BoardDAOImpl();
	public static BoardDAOImpl getInstance() {
		if(instance == null) {
			instance = new BoardDAOImpl();
		}
		return instance;
	}
	
	// 2. 커넥션 풀 객체를 보관
	DataSource dataSource;
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	// 3. 디폴트 생성자
	private BoardDAOImpl() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/jsp_pj_105");
			
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	
	@Override // 게시글 목록
	   public List<BoardDTO> boardList(int start, int end) {
	      System.out.println("DAO - boardList()");
	      
	      
	      List<BoardDTO> list = null;
	      
	      try {
	         conn = dataSource.getConnection();
	         String sql = "SELECT * "
	               + "  FROM ( "
	               + "       SELECT A.*, ROWNUM AS rn "
	               + "         FROM ( "
	               + "                SELECT num, title, content, writer, password, readCnt, regDate, "
	               + "                       (SELECT COUNT(*) FROM mvc_board_comment_tbl "
	               + "                        WHERE board_num = b.num) comment_count "
	               + "                  FROM mvc_board_tbl b "
	               + "                 WHERE show='y' "
	               + "                 ORDER BY num DESC "
	               + "                 ) A "
	               + "       ) "
	               + " WHERE rn BETWEEN ? AND ?";
	         
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setInt(1, start);
	         pstmt.setInt(2, end);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
	            // 1. list 생성
	            list = new ArrayList<BoardDTO>();
	            do {
	               // 2. dto 생성
	               BoardDTO dto = new BoardDTO();
	               
	               // 3. dto에 rs 게시글 정보를 담는다.
	               dto.setNum(rs.getInt("num"));
	               dto.setTitle(rs.getString("title"));
	               dto.setContent(rs.getString("content"));
	               dto.setWriter(rs.getString("writer"));
	               dto.setPassword(rs.getString("password"));
	               dto.setReadCnt(rs.getInt("readCnt"));
	               dto.setRegDate(rs.getDate("regDate"));
	               dto.setComment_count(rs.getInt("comment_count")); // 댓글 카운트 추가
	               
	               // 4. list에 dto를 추가한다.
	               list.add(dto);
	               
	            } while(rs.next());
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override // 게시글 작성처리 페이지
	public int boardInsert(BoardDTO dto) {
		System.out.println("DAO - boardInsert()");
		
		int insertCnt = 0;
		
		try {
			conn = dataSource.getConnection();
			String sql = "INSERT INTO mvc_board_tbl(num, title, content, writer, password, readCnt, regDate)"
					+ " VALUES((SELECT NVL(MAX(num)+1,1) FROM mvc_board_tbl), ?, ?, ?, ?, 0, sysdate)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getContent());
			pstmt.setString(3, dto.getWriter());
			pstmt.setString(4, dto.getPassword());
			
			insertCnt = pstmt.executeUpdate();
			System.out.println("DAO - 게시판 insertCnt : " + insertCnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return insertCnt;
	}
	
	@Override // 조회수 증가
	public int plusReadCnt(int num) {
		System.out.println("DAO - plusReadCnt()");
		
		// 조회수 결과
		int plusReadCntResult = 0;
		
		try {
			conn = dataSource.getConnection();
			String sql = "UPDATE mvc_board_tbl SET readCnt=readCnt+1 WHERE num=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			
			plusReadCntResult = pstmt.executeUpdate();
			System.out.println("DAO - 조회수 : " + plusReadCntResult);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return plusReadCntResult;
	}
	
	@Override // 게시글 상세페이지
	public BoardDTO getBoardDetail(int num) {
		System.out.println("DAO - getBoardDetail()");
		
		BoardDTO dto = new BoardDTO();
			
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM mvc_board_tbl WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto.setNum(rs.getInt("num"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setWriter(rs.getString("writer"));
				dto.setPassword(rs.getString("password"));
				dto.setReadCnt(rs.getInt("readCnt"));
				dto.setRegDate(rs.getDate("regDate"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;
	}
	
	@Override // 비밀번호 인증 - 비밀번호 리턴
	public String password_chk(int num, String password) {
		System.out.println("DAO - password_chk()");
		
		// 비밀번호
		String resultPassword = null;
			
		try {
			conn = dataSource.getConnection();
			
			String sql = "SELECT password FROM mvc_board_tbl WHERE num=? AND password=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, password);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				resultPassword = rs.getString("password");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return resultPassword;
	}
	
	@Override // 게시글 수정
	public int boardUpdate(BoardDTO dto) {
		System.out.println("DAO - boardUpdate()");
		
		int updateResult = 0;
		
		try {
			conn = dataSource.getConnection();
			
			String sql = "UPDATE mvc_board_tbl SET title=?, content=? WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getContent());
			pstmt.setInt(3, dto.getNum());
			
			updateResult = pstmt.executeUpdate();
			System.out.println("updateResult : "+updateResult);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return updateResult;
	}
	
	@Override // 게시글 삭제처리 페이지
	public int boardDelete(int num) {
		System.out.println("DAO - boardDelete()");
		
		int deleteResult = 0;
		
		try {
			conn = dataSource.getConnection();
			
			String sql = "UPDATE mvc_board_tbl SET SHOW='n' WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			
			deleteResult = pstmt.executeUpdate();
			System.out.println("deleteResult : "+deleteResult);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return deleteResult;
	}

	@Override // 댓글 추가 처리
	public void commentInsert(BoardCommentDTO dto) {
		System.out.println("DAO - commentInsert()");
		
		try {
			conn = dataSource.getConnection();
			String sql = "INSERT INTO mvc_board_comment_tbl(comment_num, board_num, writer, content, reg_date) "
					+ "VALUES ((SELECT NVL(MAX(comment_num+1),1) FROM mvc_board_comment_tbl), ?, ?, ?, sysdate)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dto.getBoard_num());
			pstmt.setString(2, dto.getWriter());
			pstmt.setString(3, dto.getContent());
			System.out.println(dto.toString());
			
			int insertCnt = pstmt.executeUpdate();
			System.out.println("DAO 댓글 추가 성공 여부 : "+insertCnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override // 댓글 목록
	public List<BoardCommentDTO> getCommentList(int board_num) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<BoardCommentDTO> list = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM mvc_board_comment_tbl WHERE board_num= ? ORDER BY comment_num ASC";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, board_num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {

				// 1. list 생성
				list = new ArrayList<BoardCommentDTO>();
				
				do {
					// 2. dto 생성
					BoardCommentDTO dto = new BoardCommentDTO();
					
					// 3. dto에 rs 게시글 정보를 담는다.
					dto.setComment_num(rs.getInt("comment_num"));
					dto.setBoard_num(rs.getInt("board_num"));
					dto.setWriter(rs.getString("writer"));
					dto.setContent(rs.getString("content"));
					dto.setReg_date(rs.getDate("reg_date"));
					
					// 4. list에 dto를 추가한다.
					list.add(dto);
					
				} while(rs.next());
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	//게시글 개수
	@Override
	public int boardCount() {
		System.out.println("DAO - count");
	      
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      int selectCnt = 0;
	      
	      try {
	         conn = dataSource.getConnection();
	         String sql =  "SELECT COUNT(*) as cnt FROM mvc_board_tbl";
	         pstmt = conn.prepareStatement(sql);
	         
	         rs = pstmt.executeQuery();
	         
	         if(rs.next()) {
	            selectCnt = rs.getInt("cnt");
	         }
	         
	      } catch(SQLException e) {
	         e.printStackTrace();
	      } finally {
	         // 사용한 자원해제
	         try {
	            if(rs != null) rs.close();
	            if(pstmt != null) pstmt.close();
	            if(conn != null) conn.close();
	         } catch(SQLException e) {
	            e.printStackTrace();
	         }
	      }
	      
	      return selectCnt;
	   }

}
