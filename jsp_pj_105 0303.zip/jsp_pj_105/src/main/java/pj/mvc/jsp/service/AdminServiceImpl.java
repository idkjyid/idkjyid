package pj.mvc.jsp.service;

public class AdminServiceImpl {

}
