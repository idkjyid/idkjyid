package pj.mvc.jsp.service;

public interface AdminService {

}
