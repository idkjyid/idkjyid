package pj.mvc.jsp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pj.mvc.jsp.service.CustomerServiceImpl;

@WebServlet("*.do")
// 웹 브라우저의 모든 요청을 단일 진입점, 즉 하나의 서블릿에서 처리(확장자가 .do로 끝나는 모든 요청이 진입 - 확장자를 모듈별로 분류)
/*
 *	컨트롤러(서블릿): 흐름을 제어하고, 사용자의 입력을 처리한다. 웹 브라우저의 모든 요청을 하나의 서블릿에서 처리
 *	모델(DAO, DTO): 비즈니스 로직을 처리한다
 *	뷰: 결과 화면 
 *	@WebServlet("시작url"): 웹 브라우저의 모든 요청의 단일 진입점, 즉 하나의 서블릿에서 처리(확장자가 .do로 끝나는 모든 요청의 진입)
 *	@WebServlet의 속성 값을 통해 해당 Servlet과 매핑될 url  패턴을 지정한다.
 *	@WebServlet("시작url")의 url 주소로 접속하면 톰캣 서버의 컨테이너가 매핑된 서블릿을 찾아 실행해준다.
 */
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public CustomerController() {
        super();
    }
    
    // 1단계. HTTP 요청 받음
	protected void doGet(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {
		
		action(req, res);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {
		
		doGet(req, res);
	}
	
	public void action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException { 
		
		// 한글 안깨지게 처리
		req.setCharacterEncoding("UTF-8");
		CustomerServiceImpl service = new CustomerServiceImpl();
		
		String viewPage = "";  // 결과를 뿌릴 페이지
		String uri = req.getRequestURI();
		String contextPath = req.getContextPath();
		String url = uri.substring(contextPath.length());
		
		//  전체 url => http://localhost/jsp_pj_105/*.cus
		System.out.println("uri : " + uri);  // 컨텍스트명(=플젝명) + 나머지 주소 => /jsp_pj_105/*.do 
		System.out.println("contextPath : " + contextPath);  // /jsp_pj_105
		System.out.println("url : " + url);  // /*.do
		
		// 2단계. 요청분석
		// 첫페이지
		if(url.equals("/*.do") || url.equals("/main.do")) {
			System.out.println("[url ==> /main.do]");
			
			viewPage = "index.jsp";
		
		// 회원가입 화면
		} else if(url.equals("/join.do")) {
			System.out.println("[url ==> join.do]");
			
			viewPage = "customer/join/join.jsp";
	
		//중복 확인 처리
		} else if(url.equals("/confirmIdAction.do")) {
			System.out.println("[url ==> confirmIdAction.do]");
			service.confirmIdAction(req, res);
			viewPage = "customer/join/confirmIdAction.jsp";			
		
		// 회원가입처리 화면
		} else if(url.equals("/joinAction.do")) {
			System.out.println("[url ==> joinAction.do]");
			service.signInAction(req, res);
			viewPage = "customer/join/joinAction.jsp";
		
		// 회원가입 성공
		} else if(url.equals("/mainSuccess.do")) {
			System.out.println("[url ==> mainSuccess.do]");
			
			// mainSuccess.do?insertCnt=" + insertCnt
			int cnt = Integer.parseInt(req.getParameter("insertCnt"));
			
			req.setAttribute("selectCnt", cnt);
			System.out.println("cnt : " + cnt);
			
			viewPage = "customer/login/login.jsp";
		
		// 로그인 화면
		} else if(url.equals("/login.do")) {
			System.out.println("[url ==> login.do");
			
			req.setAttribute("selectCnt", 2); //가입환영
			viewPage = "customer/login/login.jsp";
		
		// 로그인처리 화면
		} else if(url.equals("/loginAction.do")) {
			System.out.println("[url ==> loginAction.do]");
			service.loginAction(req, res);
			viewPage = "customer/login/loginAction.jsp";
		
		//로그아웃	
		} else if(url.equals("/logout.do")){
			System.out.println("[url==>logout.do");
			
			/*
			 *	세션 삭제
			 *	req.getSession().invalidate();	//일괄 세션 삭제
			 *	req.removeAttribute("세션명");	//해당 세션만 삭제
			 *	req.getSession.setAttribute("세선명",null);	//해당 세션만 삭제 
			 * 
			 */
		
			req.getSession().invalidate();
			
			//로그아웃 됐을 때 selectCnt, 2
			viewPage = "index.jsp";
			
		//회원 수정 - 인증 화면
		} else if(url.equals("/modifyCustomer.do")) {
			System.out.println("[url ==> modifyCustomer.do]");
			viewPage = "customer/mypage/customerInfo/modifyCustomer.jsp";
		
		//회원 수정 - 상세페이지	
		} else if(url.equals("/modifyDetailAction.do")) {
			System.out.println("[url ==> modifyDetailAction.do]");
			service.modifyAction(req, res);
			viewPage ="customer/mypage/customerInfo/modifyDetailAction.jsp";
		
		//회원 수정 처리	
		} else if(url.equals("/modifyCustomerAction.do")) {
			System.out.println("[url ==> modifyCustomerAction.do]");
			service.modifyCustomerAction(req, res);
			viewPage ="customer/mypage/customerInfo/modifyCustomerAction.jsp";
		
		//회원 탈퇴 - 인증화면
		} else if(url.equals("/deleteCustomer.do")){
			System.out.println("[url ==> deleteCustomer.do]");
			viewPage ="customer/mypage/customerInfo/deleteCustomer.jsp";
		
		//회원 탈퇴 처리
		} else if(url.equals("/deleteCustomerAction.do")) {
			System.out.println("[url ==> deleteCustomerAction.do]");
			service.deleteCustomerAction(req, res);
			viewPage ="customer/mypage/customerInfo/deleteCustomerAction.jsp";
		
		}
		
		// RequestDispatcher : 서블릿 또는 JSP 요청을 받은 후, 다른 컴포넌트로 요청을 위임하는 클래스(파견)
		// RequestDispatcher : 해당 viewPage로 forward(=이동)
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
		dispatcher.forward(req, res);
	}

}
